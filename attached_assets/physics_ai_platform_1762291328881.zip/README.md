# 🔬 Fizik Problem Çözüm Platformu (RAG + Gemini)

Bu proje, kullanıcı kayıt/giriş sistemi, admin paneli ve RAG destekli Gemini çözüm altyapısına sahip bir fizik problem çözüm platformudur.

## 🚀 Özellikler
- Kullanıcı kayıt / giriş (kullanıcı adı + şifre)
- Admin paneli (admin / Ferhat4755__)
- RAG (retrieval augmented generation) desteği
- Gemini API ile soru çözümü
- Kullanıcı silme, RAG veri ekleme

## 📁 Proje Yapısı
```
backend/
 ┣ data/
 ┃ ┣ users.json
 ┃ ┗ rag_data.json
 ┣ server.js
.env
.gitignore
package.json
README.md
```

## ⚙️ Kurulum
```bash
npm install
```
`.env` dosyasına Gemini API anahtarını gir:
```
GEMINI_API_KEY=AIzaSy...
```

Sunucuyu başlat:
```bash
npm start
```

## 🧠 Kullanım
POST istekleri:
- `/api/register` → { username, password }
- `/api/login` → { username, password }
- `/api/solve` → { question }
- `/api/admin` → { username: "admin", password: "Ferhat4755__" }
- `/api/admin/delete/:username`
- `/api/admin/rag/add` → { keyword, content }

Tüm cevaplar JSON döner.
