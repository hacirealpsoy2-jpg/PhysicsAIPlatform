import express from "express";
import dotenv from "dotenv";
import bodyParser from "body-parser";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";
import fs from "fs";

dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Kullanıcı veritabanı (JSON)
const USERS_FILE = "./backend/data/users.json";
const RAG_DB = "./backend/data/rag_data.json";

if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify([]));
if (!fs.existsSync(RAG_DB)) fs.writeFileSync(RAG_DB, JSON.stringify([]));

// RAG fonksiyonu (basit dosya tabanlı)
function retrieveRelevantContext(question) {
  const data = JSON.parse(fs.readFileSync(RAG_DB));
  let bestMatch = data.find(item => question.includes(item.keyword));
  return bestMatch ? bestMatch.content : "No related context found.";
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Register
app.post("/api/register", (req, res) => {
  const { username, password } = req.body;
  let users = JSON.parse(fs.readFileSync(USERS_FILE));

  if (users.find(u => u.username === username)) {
    return res.status(400).json({ message: "Kullanıcı adı zaten mevcut." });
  }
  users.push({ username, password });
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  res.json({ message: "Kayıt başarılı." });
});

// Login
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  let users = JSON.parse(fs.readFileSync(USERS_FILE));

  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ message: "Geçersiz kullanıcı adı veya şifre." });

  res.json({ message: "Giriş başarılı." });
});

// Admin panel
app.post("/api/admin", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "Ferhat4755__") {
    const users = JSON.parse(fs.readFileSync(USERS_FILE));
    return res.json({ users });
  }
  return res.status(403).json({ message: "Yetkisiz erişim." });
});

// Kullanıcı silme
app.delete("/api/admin/delete/:username", (req, res) => {
  const { username } = req.params;
  let users = JSON.parse(fs.readFileSync(USERS_FILE));
  users = users.filter(u => u.username !== username);
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  res.json({ message: `${username} silindi.` });
});

// RAG veri ekleme (admin)
app.post("/api/admin/rag/add", (req, res) => {
  const { keyword, content } = req.body;
  let data = JSON.parse(fs.readFileSync(RAG_DB));
  data.push({ keyword, content });
  fs.writeFileSync(RAG_DB, JSON.stringify(data, null, 2));
  res.json({ message: "RAG verisi eklendi." });
});

// Soru çözme (Gemini + RAG destekli)
app.post("/api/solve", async (req, res) => {
  try {
    const { question } = req.body;
    const context = retrieveRelevantContext(question);
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: `Context: ${context}
Question: ${question}`
    });
    res.json({ answer: response.response.text() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(5000, () => console.log("Server 5000 portunda çalışıyor."));
